The following contains gerbers files, pick n place files (labelled "pos"), bill of materials and cad/step files.

if any more info is required, kindly email:

al.mahir.ahmed@g.bracu.ac.bd